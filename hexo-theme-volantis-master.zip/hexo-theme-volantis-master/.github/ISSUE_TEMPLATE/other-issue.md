---
name: Other Issue
about: 此流程不予处理帮助、BUG、建议相关的内容。
title: ''
labels: 'others'
assignees: ''

---

<!-- 如果您删除此模版，我们可能会在不进行调查的情况下关闭您的 Issue。 -->

## 自检报告

<!-- Change [ ] to [x] to select (将 [ ] 换成 [x] 来选择) -->

- [ ] 我要说的内容与帮助或者BUG、建议都无关。（如果有关，请使用相关模板）


## 问题描述

<!-- 如果能够提供参考链接或者示意图更好 -->
